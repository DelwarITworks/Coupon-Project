
  <div class="category_menu">
    <div class="container-custom">
      <div class="categories">
        <div class="circle"></div>
        <ul class="d-flex justify-content-evenly align-items-center">
          <li><a href="#">Coupons</a></li>
          <li><a href="#">Store</a></li>
          <li><a href="#">Research</a></li>
          <li><a href="#">Submit Code</a></li>
        </ul>
      </div>
    </div>
  </div>