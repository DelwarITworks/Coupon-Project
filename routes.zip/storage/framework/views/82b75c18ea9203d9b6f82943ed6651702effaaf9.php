
<header>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container-custom d-flex justify-content-between align-items-center">
        <a class="navbar-brand" href="#"> <i class="fa-solid fa-tag"></i> GetCoupon</a>
        
        <div class="sing_and_login">
          <?php if(auth()->guard()->guest()): ?>
          <a href="<?php echo e(route('register')); ?>" class="btn sign_up">Sign up</a>
          <a href="<?php echo e(route('login')); ?>" class="btn join">Join</a>
          <?php else: ?>
          <?php if(Auth::user()->is_admin == 1): ?>
            
          <a href="<?php echo e(route('dashboard')); ?>" class="btn sign_up">Dashboard</a>
          <?php endif; ?>
          <a href="<?php echo e(route('logout')); ?>" class="btn join">Logout</a>

          <?php endif; ?>
        </div>
      </div>
  </nav>
</header>
    <?php /**PATH E:\xampp\htdocs\coupon\resources\views/layouts/header.blade.php ENDPATH**/ ?>