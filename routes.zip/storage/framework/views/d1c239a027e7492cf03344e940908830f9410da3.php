

<?php $__env->startSection('title','Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Start Page content -->
    <div class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-12">
                    <div class="card-box">
                        <h4 class="header-title mb-4">Account Overview</h4>

                    </div>
                </div>
            </div>
        </div> <!-- container -->

    </div> <!-- content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\coupon\resources\views/admin/index.blade.php ENDPATH**/ ?>