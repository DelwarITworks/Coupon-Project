    <!-- canvas color starts  -->

<?php
  $websites = App\Models\Admin\Coupon\Website::where('status',1)->get();
?>
    <canvas></canvas>
    <!-- canvas color ends -->

      
    <!-- banner sedtion starts  -->

    <div class="banner">
        <div class="circle1"></div>
        <div class="container-custom">
          <div class="row">
            <div class="col-md-6">
              <div class="banner_content">
                <h1>Never miss out on coupons or cashback</h1>
              </div>
            </div>
            <div class="col-md-6">
              <div class="banner_coupon ms-auto">
                <div class="row g-3">
                  <?php $__currentLoopData = $websites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $website): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-6">
                    <div class="coupon_box">
                      <div class="coupon_img">
                        <?php if($website->image): ?>
                        <img src="<?php echo e(asset('storage/app/public/'.$website->image)); ?>" alt="adobe">
                        <?php else: ?>
                        
                        <img src="<?php echo e(asset('public/front/assets/image/amazon2.jpg')); ?>" alt="adobe">
                        <?php endif; ?>
                      </div>
                      <div class="coupon_content text-center">
                        <a href="<?php echo e(route('website.coupons',$website->slug)); ?>"><?php echo e($website->name); ?></a>
                      </div>
                    </div>
                  </div>
                    
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
      
      <!-- banner sedtion ends --><?php /**PATH E:\xampp\htdocs\coupon\resources\views/layouts/bannar.blade.php ENDPATH**/ ?>