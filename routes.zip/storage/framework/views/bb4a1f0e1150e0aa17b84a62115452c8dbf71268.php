
<?php
$websites = App\Models\Admin\Coupon\Website::where('status',1)->get();
?>
        <div class="col-sm-3">
            <div class="coupon_category">
              <div class="retailers">
                <div class="retailers_heading">
                  <h4>Similar Coupons</h4>
                </div>
                <div class="retailers_content">
                  <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <a href=""><?php echo e(Str::words($coupon->title,'3','..')); ?></a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
            </div>
  
            <div class="coupon_category">
              <div class="retailers">
                <div class="retailers_heading">
                  <h4>Similar Coupons</h4>
                </div>
                <div class="retailers_content">
                  <div class="row g-3">
                    <?php $__currentLoopData = $websites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $website): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6">
                      <div class="sm_box"> 
                        <?php if($website->image): ?>
                        <img src="<?php echo e(asset('storage/app/public/'.$website->image)); ?>" alt="adobe">
                        <?php else: ?>
                        
                        <img src="<?php echo e(asset('public/front/assets/image/amazon2.jpg')); ?>" alt="adobe">
                        <?php endif; ?>
                        <p class="text-center text-muted mt-1 mb-0"><?php echo e($website->name); ?></p>
                      </div>
                    </div>
                      
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    
                  </div>
                  
                </div>
              </div>
            </div>
          </div><?php /**PATH E:\xampp\htdocs\coupon\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>