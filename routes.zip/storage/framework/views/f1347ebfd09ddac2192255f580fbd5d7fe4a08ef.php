
<?php $__env->startSection('content'); ?>

<main class="my-5">

  <div class="coupon_container">
    <div class="container-custom">
      <div class="row">

        <div class="col-sm-9">
          <div class="coupons">
            <!-- <a class="popup-with-zoom-anim" href="#product">click</a> -->
            <div class="row g-4">
              <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-sm-6">
                <a class="popup-with-zoom-anim" href="#<?php echo e($coupon->id); ?>">
                  <div class="coupon_card">

                    <div class="card_left">
                      <div class="offer">
                        <div class="offer_top">
                          <span><?php echo e($coupon->discount); ?>%</span>
                          <span>OFF</span>
                        </div>
                        <div class="offer_bottom">
                          <span>coupon code</span>
                        </div>
                      </div>
                    </div>

                    <div class="card_right">
                      <div class="card_text">
                        <h4>Save <?php echo e($coupon->discount); ?>% Off</h4>
                        <p><?php echo e(Str::words($coupon->title,'8','..')); ?></p>
                      </div>
                      <div class="card_btn">
                        <a href="#" class="btn"><?php echo e($coupon->promo_code); ?></a>
                      </div>
                    </div>

                  </div> 
                </a>
              </div>

              
              <!-- product popups starts -->
              <div class="popup zoom-anim-dialog fr mfp-hide" id="<?php echo e($coupon->id); ?>">
                <div class="popup_circle circle_top"></div>
                <div class="popup_circle circle_bottom"></div>
                <div class="popup_content">
                  <div class="copy d-flex justify-content-center align-items-center">
                    <input class="coupon_text border-0" type="text" value="<?php echo e($coupon->promo_code); ?>">
                    <button class="copy_btn border-0" href="#">Copy</button>
                  </div>
                  <div class="go_btn">
                    <a target="_blank" href="<?php echo e($coupon->website->link); ?>" class="btn">Go to themeforest <i class="fa-solid fa-angle-right ms-2"></i></a>
                  </div>
                </div>
              </div>
                
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>

          <div class="coupons coupon_bottom">
            <h4>Popular Categories</h4>

            <div class="category_box mt-4">
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="cat">
                <i class="fa-solid fa-check"></i>
                <a href="#"><?php echo e($category->name); ?></a>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>

        

        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        

      </div>
    </div>
  </div>

  <?php echo $__env->make('layouts.top_offer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
</main>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\coupon\resources\views/user/coupon/website_coupon.blade.php ENDPATH**/ ?>