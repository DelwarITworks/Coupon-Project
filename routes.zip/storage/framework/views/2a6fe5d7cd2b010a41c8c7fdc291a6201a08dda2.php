
  <div class="top_offer py-5">
    <div class="container-custom">
      <div class="head">
        <h4>Top Offers</h4>
      </div>

      <div class="offer_container">
        <div class="row g-3">
          <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($coupon->best_offer = 1): ?>
          <div class="col-md-3">
            <div class="offer_box">
              <div class="offer_image">
                <?php if($coupon->image): ?>
                <img src="<?php echo e(asset('storage/app/public/'.$coupon->image)); ?>" alt="adobe">
                <?php else: ?>
                
                <img src="<?php echo e(asset('public/front/assets/image/amazon2.jpg')); ?>" alt="adobe">
                <?php endif; ?>
              </div>
              <div class="offer_content">
                <h6>sale</h6>
                <p><?php echo e(Str::words($coupon->title,'8','..')); ?></p>
                <span>Sponsored</span>
              </div>
            </div>
          </div>

          <?php endif; ?>
            
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
      </div>
    </div>
  </div><?php /**PATH E:\xampp\htdocs\coupon\resources\views/layouts/top_offer.blade.php ENDPATH**/ ?>