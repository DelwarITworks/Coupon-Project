


<?php $__env->startSection('content'); ?>


<div class="content">
    <!-- Start Content-->
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h4 class="header-title mb-4" style="float: left;">View coupons</h4>
                <h4 class="header-title mb-4" style="float: right;"><a href="<?php echo e(route('create.coupon')); ?>" class="btn btn-outline-primary">Add coupon</a></h4>
            </div>
        </div>
    </div>
</div>


<div class="content">
    <!-- Start Content-->
    <div class="container-fluid">
        <div class="row">
            <!-- end col -->
            <div class="col-md-12">
                <div class="card-box">
                    <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Success!</strong> <?php echo e(session('success')); ?>.
                    </div>
                    <?php endif; ?>
                    <?php if(session('deletesuccess')): ?>
                    <div class="alert alert-danger">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Success!</strong> <?php echo e(session('deletesuccess')); ?>.
                    </div>
                    <?php endif; ?>

                    <table id="example" class="table table-striped table-bordered" style="width:100%">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">Sl</th>
                                <th scope="col">Title</th>
                                <th scope="col">Category</th>
                                <th scope="col">Image</th>
                                <th scope="col">Description</th>
                                <th scope="col">Date</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($count++); ?></td>
                                <td><?php echo e($coupon->title); ?></td>
                                <td><?php echo e($coupon->category_id); ?></td>
                                <td><img src="<?php echo e(asset('/storage/app/public/'.$coupon->image)); ?>" height="50px" width="auto"alt=""></td>
                                <td><?php echo Str::words($coupon->description,'16','...'); ?></td>
                                <td><?php echo e($coupon->created_at->format('d/m/Y')); ?></td>

                                <td>
                                    <a class="btn btn-outline-info" href="<?php echo e(route('edit.coupon',$coupon->id)); ?>">Edit</a>
                                    <a class="btn btn-outline-danger" id="delete" href="<?php echo e(route('delete.coupon',$coupon->id)); ?>">Delete</a>
                                    <?php if($coupon->status == 1): ?>
                                        <a class="btn btn-outline-primary" href="<?php echo e(route('deactive.coupon',$coupon->id)); ?>">Active</a>
                                    <?php else: ?>
                                        <a class="btn btn-outline-warning" href="<?php echo e(route('active.coupon',$coupon->id)); ?>">Deactive</a>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>

                </div>
            </div>
        </div>
        <!-- end row -->
    </div> <!-- end container-fluid -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\coupon\resources\views/admin/coupon/index_coupon.blade.php ENDPATH**/ ?>